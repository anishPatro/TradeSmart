package com.groww.anish.stocks_portfolio.serviceTest;

import com.groww.anish.stocks_portfolio.dto.TradeDTO;
import com.groww.anish.stocks_portfolio.dto.TradeResponseDTO;
import com.groww.anish.stocks_portfolio.entity.Portfolio;
import com.groww.anish.stocks_portfolio.entity.PortfolioStock;
import com.groww.anish.stocks_portfolio.entity.Stock;
import com.groww.anish.stocks_portfolio.entity.User;
import com.groww.anish.stocks_portfolio.repository.PortfolioRepository;
import com.groww.anish.stocks_portfolio.repository.PortfolioStockRepository;
import com.groww.anish.stocks_portfolio.repository.StockRepository;
import com.groww.anish.stocks_portfolio.repository.UserRepository;
import com.groww.anish.stocks_portfolio.service.TradeServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TradeServiceTest {

    @Mock
    private StockRepository sRepo;

    @Mock
    private PortfolioRepository pRepo;

    @Mock
    private PortfolioStockRepository psRepo;

    @Mock
    private UserRepository uRepo;

    @InjectMocks
    private TradeServiceImpl tradeService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    @Test
    void testProcessTradeBuySuccess() {
        // Arrange
        TradeDTO tradeRequest = new TradeDTO();
        tradeRequest.setUserId(1L);
        tradeRequest.setStockId(1L);
        tradeRequest.setTradeType("BUY");
        tradeRequest.setQuantity(10);

        Stock stock = new Stock();
        stock.setId(1L);
        stock.setName("Test Stock");
        stock.setClosePrice(100.0);
        stock.setQuantity(50);

        User user = new User();
        user.setId(1L);
        user.setName("Test User");

        Portfolio portfolio = new Portfolio();
        portfolio.setId(1L);
        portfolio.setUser(user);
        portfolio.setTotalBuyPrice(0.0);

        PortfolioStock existingPortfolioStock = new PortfolioStock();
        existingPortfolioStock.setPortfolio(portfolio);
        existingPortfolioStock.setStock(stock);
        existingPortfolioStock.setQuantity(0);
        existingPortfolioStock.setBuyPrice(0.0);

        when(sRepo.findById(1L)).thenReturn(Optional.of(stock));
        when(uRepo.findById(1L)).thenReturn(Optional.of(user));
        when(pRepo.findByUser(user)).thenReturn(Optional.of(portfolio));
        when(psRepo.findByPortfolioAndStock(portfolio, stock)).thenReturn(Optional.of(existingPortfolioStock));

        TradeResponseDTO response = tradeService.processTrade(tradeRequest);

        assertEquals("Success", response.getStatus());
        assertEquals("Stock brought successfully.", response.getMessage());
        assertEquals(10, existingPortfolioStock.getQuantity());
        assertEquals(100, existingPortfolioStock.getBuyPrice());
        assertEquals(1000.0, portfolio.getTotalBuyPrice());
        assertEquals(40, stock.getQuantity());

        verify(psRepo, times(1)).save(existingPortfolioStock);
        verify(pRepo, times(1)).save(portfolio);
        verify(sRepo, times(1)).save(stock);
    }

    @Test
    void testProcessTradeBuyCreatesNewPortfolioStock() {
        TradeDTO tradeRequest = new TradeDTO();
        tradeRequest.setUserId(1L);
        tradeRequest.setStockId(1L);
        tradeRequest.setTradeType("BUY");
        tradeRequest.setQuantity(10);

        Stock stock = new Stock();
        stock.setId(1L);
        stock.setName("Test Stock");
        stock.setClosePrice(100.0);
        stock.setQuantity(50);

        User user = new User();
        user.setId(1L);
        user.setName("Test User");

        Portfolio portfolio = new Portfolio();
        portfolio.setId(1L);
        portfolio.setUser(user);
        portfolio.setTotalBuyPrice(0.0);

        when(sRepo.findById(1L)).thenReturn(Optional.of(stock));
        when(uRepo.findById(1L)).thenReturn(Optional.of(user));
        when(pRepo.findByUser(user)).thenReturn(Optional.of(portfolio));
        when(psRepo.findByPortfolioAndStock(portfolio, stock)).thenReturn(Optional.empty());

        when(psRepo.save(any(PortfolioStock.class))).thenAnswer(invocation -> invocation.getArgument(0));

        TradeResponseDTO response = tradeService.processTrade(tradeRequest);

        assertEquals("Success", response.getStatus());
        assertEquals("Stock brought successfully.", response.getMessage());
        assertEquals(40, stock.getQuantity());
        assertEquals(1000.0, portfolio.getTotalBuyPrice());

        verify(psRepo, times(1)).save(any(PortfolioStock.class));
        verify(pRepo, times(1)).save(portfolio);
        verify(sRepo, times(1)).save(stock);
    }

    @Test
    void testProcessTradeBuyInsufficientStock() {

        TradeDTO tradeRequest = new TradeDTO();
        tradeRequest.setUserId(1L);
        tradeRequest.setStockId(1L);
        tradeRequest.setTradeType("BUY");
        tradeRequest.setQuantity(100);

        Stock stock = new Stock();
        stock.setId(1L);
        stock.setName("Test Stock");
        stock.setClosePrice(100.0);
        stock.setQuantity(50);

        User user = new User();
        user.setId(1L);
        user.setName("Test User");

        Portfolio portfolio = new Portfolio();
        portfolio.setId(1L);
        portfolio.setUser(user);
        portfolio.setTotalBuyPrice(0.0);

        when(sRepo.findById(1L)).thenReturn(Optional.of(stock));
        when(uRepo.findById(1L)).thenReturn(Optional.of(user));
        when(pRepo.findByUser(user)).thenReturn(Optional.of(portfolio));
        when(psRepo.findByPortfolioAndStock(portfolio, stock)).thenReturn(Optional.empty());

        TradeResponseDTO response = tradeService.processTrade(tradeRequest);

        assertEquals("Failure", response.getStatus());
        assertEquals("Insufficient stock quantity available to buy.", response.getMessage());

        verify(psRepo, never()).save(any(PortfolioStock.class));
        verify(pRepo, never()).save(any(Portfolio.class));
        verify(sRepo, never()).save(any(Stock.class));
    }

    @Test
    void testProcessTradeSellSuccess() {
        TradeDTO tradeRequest = new TradeDTO();
        tradeRequest.setUserId(1L);
        tradeRequest.setStockId(1L);
        tradeRequest.setTradeType("SELL");
        tradeRequest.setQuantity(10);

        Stock stock = new Stock();
        stock.setId(1L);
        stock.setName("Test Stock");
        stock.setClosePrice(100.0);
        stock.setQuantity(50);

        User user = new User();
        user.setId(1L);
        user.setName("Test User");

        Portfolio portfolio = new Portfolio();
        portfolio.setId(1L);
        portfolio.setUser(user);
        portfolio.setTotalBuyPrice(1800.0);
        portfolio.setTotalProfitLoss(0.0);

        PortfolioStock portfolioStock = new PortfolioStock();
        portfolioStock.setStock(stock);
        portfolioStock.setPortfolio(portfolio);
        portfolioStock.setQuantity(20);
        portfolioStock.setBuyPrice(90.0);

        when(sRepo.findById(1L)).thenReturn(Optional.of(stock));
        when(uRepo.findById(1L)).thenReturn(Optional.of(user));
        when(pRepo.findByUser(user)).thenReturn(Optional.of(portfolio));
        when(psRepo.findByPortfolioAndStock(portfolio, stock)).thenReturn(Optional.of(portfolioStock));

        TradeResponseDTO response = tradeService.processTrade(tradeRequest);

        assertEquals("Success", response.getStatus());
        assertEquals("Stock sold successfully.", response.getMessage());

        verify(psRepo, times(1)).save(any(PortfolioStock.class));
        verify(psRepo, never()).delete(any(PortfolioStock.class));
        verify(pRepo, times(1)).save(portfolio);
        verify(sRepo, times(1)).save(stock);

        double expectedGainLoss = (stock.getClosePrice() - portfolioStock.getBuyPrice()) * tradeRequest.getQuantity();
        assertEquals(expectedGainLoss, portfolioStock.getGainLoss(), 0.01);
        assertEquals(800.0, portfolio.getTotalBuyPrice(), 0.01);
        assertEquals(expectedGainLoss, portfolio.getTotalProfitLoss(), 0.01);
    }

    @Test
    void testProcessTradeSellInsufficientStock() {

        TradeDTO tradeRequest = new TradeDTO();
        tradeRequest.setUserId(1L);
        tradeRequest.setStockId(1L);
        tradeRequest.setTradeType("SELL");
        tradeRequest.setQuantity(30);

        Stock stock = new Stock();
        stock.setId(1L);
        stock.setName("Test Stock");
        stock.setClosePrice(100.0);
        stock.setQuantity(50);

        User user = new User();
        user.setId(1L);
        user.setName("Test User");

        Portfolio portfolio = new Portfolio();
        portfolio.setId(1L);
        portfolio.setUser(user);
        portfolio.setTotalBuyPrice(1000.0);

        PortfolioStock portfolioStock = new PortfolioStock();
        portfolioStock.setStock(stock);
        portfolioStock.setPortfolio(portfolio);
        portfolioStock.setQuantity(20);
        portfolioStock.setBuyPrice(90.0);

        when(sRepo.findById(1L)).thenReturn(Optional.of(stock));
        when(uRepo.findById(1L)).thenReturn(Optional.of(user));
        when(pRepo.findByUser(user)).thenReturn(Optional.of(portfolio));
        when(psRepo.findByPortfolioAndStock(portfolio, stock)).thenReturn(Optional.of(portfolioStock));

        TradeResponseDTO response = tradeService.processTrade(tradeRequest);

        assertEquals("Failure", response.getStatus());
        assertEquals("Insufficient stock quantity to sell.", response.getMessage());

        verify(psRepo, never()).save(any(PortfolioStock.class));
        verify(psRepo, never()).delete(any(PortfolioStock.class));
        verify(pRepo, never()).save(any(Portfolio.class));
        verify(sRepo, never()).save(any(Stock.class));
    }

}
