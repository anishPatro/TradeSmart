package com.groww.anish.stocks_portfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class StocksPortfolioApplicationTests {

	@Test
	void contextLoads() {
		assertTrue( true);
	}

}
