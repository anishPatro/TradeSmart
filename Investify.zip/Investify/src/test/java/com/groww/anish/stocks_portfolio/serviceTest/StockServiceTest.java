package com.groww.anish.stocks_portfolio.serviceTest;

import com.groww.anish.stocks_portfolio.dto.StocksDTO;
import com.groww.anish.stocks_portfolio.entity.Stock;
import com.groww.anish.stocks_portfolio.exception.ResourceNotFoundException;
import com.groww.anish.stocks_portfolio.repository.StockRepository;
import com.groww.anish.stocks_portfolio.service.StockServiceImpl;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


public class StockServiceTest {

    @Mock
    private StockRepository sRepo;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private StockServiceImpl stockService;

    @BeforeEach
    void setUp(){
        MockitoAnnotations.openMocks(this);
    }

    public static MultipartFile createMultipartFile(InputStream inputStream, String fileName, String contentType) throws Exception {
        // Convert InputStream to byte array
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] data = new byte[1024];
        int bytesRead;
        while ((bytesRead = inputStream.read(data, 0, data.length)) != -1) {
            buffer.write(data, 0, bytesRead);
        }

        byte[] bytes = buffer.toByteArray();

        // Create MultipartFile using MockMultipartFile
        return new MockMultipartFile(fileName, fileName, contentType, bytes);
    }

    @Test
    void testProcessCsvFile_Success() throws Exception {

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        CSVPrinter printer = new CSVPrinter(new OutputStreamWriter(outputStream), CSVFormat.DEFAULT.withHeader(
                "name", "openPrice", "closePrice", "highPrice", "lowPrice", "settlementPrice", "quantity"));

        printer.printRecord("APPLE", "120.0", "125.0", "130.0", "115.0", "126.0", "100");
        printer.close();

        ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());

        MultipartFile file = createMultipartFile(inputStream, "stocks.csv", "text/csv");

        StocksDTO stockDTO = new StocksDTO();
        stockDTO.setName("APPLE");
        stockDTO.setOpenPrice(120.0);
        stockDTO.setClosePrice(125.0);
        stockDTO.setHighPrice(130.0);
        stockDTO.setLowPrice(115.0);
        stockDTO.setSettlementPrice(126.0);
        stockDTO.setQuantity(100);

        Stock stock = new Stock();
        stock.setName("APPLE");
        stock.setOpenPrice(120.0);
        stock.setClosePrice(125.0);
        stock.setHighPrice(130.0);
        stock.setLowPrice(115.0);
        stock.setSettlementPrice(126.0);
        stock.setQuantity(100);

        when(modelMapper.map(any(StocksDTO.class), eq(Stock.class))).thenReturn(stock);
        when(modelMapper.map(any(Stock.class), eq(StocksDTO.class))).thenReturn(stockDTO);

        when(sRepo.findByName("APPLE")).thenReturn(Optional.empty());
        when(sRepo.save(stock)).thenReturn(stock);
        when(sRepo.findAll()).thenReturn(List.of(stock));

        List<StocksDTO> result = stockService.processCsvFile(file);

        System.out.println("Result list: " + result);

        assertNotNull(result, "Result should not be null");
        assertEquals(1, result.size(), "Result list should contain exactly 1 item");
        assertNotNull(result.get(0), "First element should not be null");
        assertEquals("APPLE", result.get(0).getName());
        assertEquals(120.0, result.get(0).getOpenPrice());
        assertEquals(125.0, result.get(0).getClosePrice());
        assertEquals(130.0, result.get(0).getHighPrice());
        assertEquals(115.0, result.get(0).getLowPrice());
        assertEquals(126.0, result.get(0).getSettlementPrice());
        assertEquals(100, result.get(0).getQuantity());

        verify(sRepo, times(1)).save(stock);
        verify(sRepo, times(1)).findByName("APPLE");
    }

    @Test
    void testGetAllStocks() {
        Stock stock1 = new Stock();
        stock1.setName("APPLE");

        Stock stock2 = new Stock();
        stock2.setName("GOOGLE");

        List<Stock> stocks = Arrays.asList(stock1, stock2);

        StocksDTO stockDTO1 = new StocksDTO();
        stockDTO1.setName("APPLE");

        StocksDTO stockDTO2 = new StocksDTO();
        stockDTO2.setName("GOOGLE");

        when(sRepo.findAll()).thenReturn(stocks);
        when(modelMapper.map(stock1, StocksDTO.class)).thenReturn(stockDTO1);
        when(modelMapper.map(stock2, StocksDTO.class)).thenReturn(stockDTO2);

        List<StocksDTO> result = stockService.getAllStocks();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("APPLE", result.get(0).getName());
        assertEquals("GOOGLE", result.get(1).getName());
        verify(sRepo, times(1)).findAll();
    }

    @Test
    void testGetStockById_Success() {

        Stock stock = new Stock();
        stock.setId(1L);
        stock.setName("APPLE");

        StocksDTO stockDTO = new StocksDTO();
        stockDTO.setName("APPLE");

        when(sRepo.findById(1L)).thenReturn(Optional.of(stock));
        when(modelMapper.map(stock, StocksDTO.class)).thenReturn(stockDTO);

        StocksDTO result = stockService.getStockById(1L);

        assertNotNull(result);
        assertEquals("APPLE", result.getName());
        verify(sRepo, times(1)).findById(1L);
    }

    @Test
    void testGetStockById_ResourceNotFound() {

        when(sRepo.findById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(ResourceNotFoundException.class, () -> stockService.getStockById(1L));
        assertEquals("Stock not found with id: 1", exception.getMessage());
        verify(sRepo, times(1)).findById(1L);
    }

}
