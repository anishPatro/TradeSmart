package com.groww.anish.stocks_portfolio.serviceTest;

import com.groww.anish.stocks_portfolio.dto.PortfolioResponseDTO;
import com.groww.anish.stocks_portfolio.dto.PortfolioStockDTO;
import com.groww.anish.stocks_portfolio.entity.Portfolio;
import com.groww.anish.stocks_portfolio.entity.PortfolioStock;
import com.groww.anish.stocks_portfolio.entity.Stock;
import com.groww.anish.stocks_portfolio.entity.User;
import com.groww.anish.stocks_portfolio.repository.PortfolioRepository;
import com.groww.anish.stocks_portfolio.repository.PortfolioStockRepository;
import com.groww.anish.stocks_portfolio.repository.UserRepository;
import com.groww.anish.stocks_portfolio.service.PortfolioServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class PortfolioServiceTest {

    @Mock
    private UserRepository uRepo;

    @Mock
    private PortfolioRepository pRepo;

    @Mock
    private PortfolioStockRepository psRepo;

    @InjectMocks
    private PortfolioServiceImpl psService;

    @BeforeEach
    void setUp(){
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetPortfolio_Success(){

        User user = new User();
        user.setId(1L);
        user.setName("Test user");
        user.setEmail("test@gmail.com");
        user.setPhone("9812378345");

        Stock stock = new Stock();
        stock.setId(1L);
        stock.setName("HUL");
        stock.setQuantity(200);
        stock.setClosePrice(150.0);

        Portfolio portfolio = new Portfolio();
        portfolio.setId(1L);
        portfolio.setUser(user);
        portfolio.setTotalBuyPrice(1000.0);
        portfolio.setTotalPLPercentage(20.0);
        portfolio.setTotalProfitLoss(200.0);

        PortfolioStock ps = new PortfolioStock();
        ps.setPortfolio(portfolio);
        ps.setStock(stock);
        ps.setQuantity(10);
        ps.setBuyPrice(120.0);
        ps.setCurrentPrice(stock.getClosePrice());
        ps.setGainLoss(ps.calculateGainLoss());

        List<PortfolioStock> portfolioStocks = List.of(ps);

        when(uRepo.findById(user.getId())).thenReturn(Optional.of(user));
        when(pRepo.findByUser(user)).thenReturn(Optional.of(portfolio));
        when(psRepo.findByPortfolio(portfolio)).thenReturn(portfolioStocks);

        PortfolioResponseDTO result = psService.getPortfolio(user.getId());

        assertNotNull(result);
        assertEquals(1, result.getHoldings().size());
        assertEquals(1500.0, result.getTotalPortfolioHolding());
        assertEquals(1000.0, result.getTotalBuyPrice());
        assertEquals(200.0, result.getTotalProfitLoss());
        assertEquals(20.0, result.getTotalPLPercentage());

        PortfolioStockDTO holding = result.getHoldings().get(0);
        assertEquals("HUL", holding.getStockName());
        assertEquals(1L, holding.getStockId());
        assertEquals(10, holding.getQuantity());
        assertEquals(120.0, holding.getBuyPrice());
        assertEquals(150.0, holding.getCurrentPrice());
        assertEquals(300.0, holding.getGainLoss());

        verify(uRepo, times(1)).findById(user.getId());
        verify(pRepo, times(1)).findByUser(user);
        verify(psRepo, times(1)).findByPortfolio(portfolio);

    }

    @Test
    void testGetPortfolio_UserNotFound() {

        Long userId = 1L;

        when(uRepo.findById(userId)).thenReturn(Optional.empty());

        PortfolioResponseDTO result = psService.getPortfolio(userId);

        assertNull(result);

        verify(uRepo, times(1)).findById(userId);
        verify(pRepo, never()).findByUser(any());
        verify(psRepo, never()).findByPortfolio(any());
    }

    @Test
    void testGetPortfolio_PortfolioNotFound() {

        Long userId = 1L;

        User user = new User();
        user.setId(userId);
        user.setName("John Doe");
        user.setEmail("john.doe@example.com");
        user.setPhone("1234567890");

        when(uRepo.findById(userId)).thenReturn(Optional.of(user));
        when(pRepo.findByUser(user)).thenReturn(Optional.empty());

        PortfolioResponseDTO result = psService.getPortfolio(userId);

        assertNull(result);

        verify(uRepo, times(1)).findById(userId);
        verify(pRepo, times(1)).findByUser(user);
        verify(psRepo, never()).findByPortfolio(any());
    }
}
