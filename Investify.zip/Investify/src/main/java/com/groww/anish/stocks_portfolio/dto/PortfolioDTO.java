package com.groww.anish.stocks_portfolio.dto;

public class PortfolioDTO {

}
