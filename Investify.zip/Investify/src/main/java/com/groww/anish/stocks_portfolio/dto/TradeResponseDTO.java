package com.groww.anish.stocks_portfolio.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TradeResponseDTO {
    private String status;
    private String message;
}
